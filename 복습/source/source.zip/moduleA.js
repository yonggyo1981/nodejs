const even = "짝수";
const odd = "홀수";

module.exports = {
	even,
	odd,
};