const B = require("./globalB");
global.message = "globalA.js 에서 설정한 메세지...";
B();
