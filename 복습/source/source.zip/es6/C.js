function a(num1, num2) {
	return num1 + num2;
}
export default a;