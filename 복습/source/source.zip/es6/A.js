import B from "./B.mjs";
console.log(B);

import C from "./C.js";
console.log(C(10,20));