
module.exports = function() {
		console.log(global.message);
};